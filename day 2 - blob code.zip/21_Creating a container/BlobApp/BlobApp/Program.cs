﻿using Azure.Storage.Blobs;

string connectionString = "DefaultEndpointsProtocol=https;AccountName=accenture1153a;AccountKey=umdllZbv5DI3Xl1xyVcL0ZY0v0/6t5taLU6kEGTtzHACgx3fD5iVzBobU5g378TCH5w2E0n3HVZc+AStEg5ygg==;EndpointSuffix=core.windows.net";
string containerName = "data2";

BlobServiceClient blobServiceClient = new BlobServiceClient(connectionString);

Console.WriteLine("Creating the container");

await blobServiceClient.CreateBlobContainerAsync(containerName);

/*
If you want to specify properties for the container

await blobServiceClient.CreateBlobContainerAsync(containerName,Azure.Storage.Blobs.Models.PublicAccessType.Blob);
*/
Console.WriteLine("Container creation complete");